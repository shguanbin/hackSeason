# hackSeason ghost博客主题
### [实地查看](http://hackbin.cn/)

根据最新版ghost博客默认主题修改的主题，主要修改了首页，其他页面只做了小调整

## 主题特色
* 下拉菜单，搜索框（暂未支持中文，以后更新支持）
* 首页渐变banner,根据季节变换，可在后台自定义，稍后详解
* 根据季节法定节日变化的标语，可在后台自定义，稍后详解
* 日历，包括农历自动显示
* 改变以往点击切换翻页为滚动自动翻页
* 右侧作者列表，按文章数降序排列，点击可进入该作者主页
* 右侧云标签，展示所有数量部位0的标签，按文章数降序排列
* 其他项为最新博客安装以及本主题使用配置教程
* 本主题对主页进行了重写，其他页面仅有些小调整

## 部分截图
* 首页
![截图](http://hackbinimg.luokangyuan.com/screenshoot/shouye.png)
* 菜单
![截图](http://hackbinimg.luokangyuan.com/screenshoot/caidan.png)
* 文章详情
![截图](http://hackbinimg.luokangyuan.com/screenshoot/post.png)